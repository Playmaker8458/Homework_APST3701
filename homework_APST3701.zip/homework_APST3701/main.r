# read.csv เป็นคำสั่งที่จะใช้ในการอ่านไฟล์ csv
pactice.data <- read.csv(file = "C:\\Users\\Playm\\Downloads\\homework_APST3701\\file_csv\\pactice 2.csv", header = TRUE) # กรุณาเปลี่ยน path ที่จะอ่านไฟล์ csv เป็นของตัวเอง

data1 <- pactice.data[2] # ดึงคอลัมน์ที่ 2 มาเก็ยไว้ที่ตัวแปร data1
data2 <- pactice.data[3] # ดึงคอลัมน์ที่ 3 มาเก็ยไว้ที่ตัวแปร data2

pactice.Transfer <- lm(pactice.data$Transfer_value ~ pactice.data$Transfer_Volume) 
print(summary(pactice.Transfer))

plot(unlist(data1) ,unlist(data2))
abline(lm(pactice.data$Transfer_value ~ pactice.data$Transfer_Volume))